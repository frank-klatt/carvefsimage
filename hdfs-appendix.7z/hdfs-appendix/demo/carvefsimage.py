# This script exists to carve fsimage files from corrupted/damaged Hadoop system images.
import sys # import sys for argv
import os # Import operating system interface
import re # Import regular expressions
import binascii

rawinput = sys.argv[1] # System image passes from first argument of cmd
FSI_SOF = b'\x48\x44\x46\x53\x49\x4D\x47\x31' # Start of file marker "HDFSIMG1"
FSI_EOF = b'\x53\x54\x52\x49\x4E\x47\x5F\x54\x41\x42\x4C\x45' # Marker near end of file "STRING_TABLE"

file_obj=open(rawinput,'rb') # argv[1] should pass the first argument from the run cmd
data=file_obj.read()
# print("CHECKING 190-192", binascii.hexlify(data[190:192]))
file_obj.close()

SOF_list=[match.start() for match in re.finditer(re.escape(FSI_SOF),data)] # Generate list of offsets for SOF
EOF_list=[match.start() for match in re.finditer(re.escape(FSI_EOF),data)] # Generate list of offsets for EOF
HF_dict={} # dictionary for describing which offsets are headers (0) and footers (1)
off_pairs=[] # working list of valid offset pairs to be used for carving
# seeking=0 # determines which structure type is being hunted next to be added to offpairs. 0=header 1=footer
working_header=-1 # used for building valid pairs

for offset in SOF_list: # put header offsets into dictionary with value 0
    HF_dict[offset]=0
for offset in EOF_list: # put footer offsets into dictionary with value 1
    HF_dict[offset]=1
for offset, type in sorted(HF_dict.items()): # begin looping through dictionary in order of offset to build true pairs
    if type==0: # is the offset a header?
        working_header=offset # write it to the working header variable
    else: # if it's not a header
        if working_header!=-1: # if the working_header has a value...
            off_pairs.append([working_header, offset]) # that means we have found a footer following a header, so write the pair
            working_header=-1 # reset the loop and remove the previous header from working header

print("{} , {}".format(SOF_list, EOF_list)) # display the lists of starts and ends
print(off_pairs)

for pair in off_pairs:
    # fileisvalidated=0
    # i=0
    for i in range(0,50): # while fileisvalidated == 0 and i < 50:
        subdata=data[pair[0]:pair[1]+12+i] # for each SOF entry in SOF_list, set subdata as the data between sof offset and eof offset + 12 bytes (for "string_table") + extra byte per attempt
        # print("CHECKING 190-192", binascii.hexlify(subdata[190:192]))
        carve_filename="carvedfsimage"+str(i)+"-"+str(pair[0])+"-"+str(pair[1]) # set the file name to be written
        carve_obj=open(carve_filename,'wb') # open a new file with the set name. write as bin
        carve_obj.write(subdata) # write the bytes selected as subdata to the file
        carve_obj.close() # finish the file.
        print ("Found a fsimage and carving it to "+carve_filename) # display which file was written
        # os.system("cp "+carve_filename+" backupcarve") # copy the carve before pushing to oiv for debug
        if os.system("hdfs oiv -p XML -i "+carve_filename+" -o fsimagetmp.xml") == 0:
            print("File "+carve_filename+" Validated")
            break # fileisvalidated=1
        else:
            os.system("rm "+carve_filename)
            print("\n------------\n")
            # i=i+1
    os.system("rm fsimagetmp.xml")
        # os.system("rm "+carve_filename)